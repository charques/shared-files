declare module 'temp' {
  export function track();
  export function mkdirSync(name: string): string;
}
