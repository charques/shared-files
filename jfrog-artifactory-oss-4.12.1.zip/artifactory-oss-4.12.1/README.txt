For the Artifactory user guide and installation instructions please visit:

   http://wiki.jfrog.org/confluence/display/RTF

The default administrator user is:
username: admin
password: password
